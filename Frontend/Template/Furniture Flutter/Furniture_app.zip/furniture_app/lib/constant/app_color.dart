import 'package:flutter/material.dart';

class AppColor {
  static Color intoColor = Color(0xff0C8A7B);
  static Color deselect = Color(0xff828A89);
  static Color appBackgroundColor = Color(0xffF9F9F9);
}