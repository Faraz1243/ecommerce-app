import 'package:flutter/material.dart';

class AppTextStyle {
  static TextStyle introTextStyle(){
    return TextStyle(color: Colors.red);
  }
}