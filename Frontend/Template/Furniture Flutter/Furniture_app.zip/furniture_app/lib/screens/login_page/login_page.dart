import 'package:flutter/material.dart';
import 'package:furniture_app/extenstion/text_extension.dart';
import 'package:get/get.dart';

import '../../constant/app_color.dart';
import '../../constant/app_icon.dart';
import '../bottom_navigation_bar.dart';
import '../homepage/home_page.dart';
import '../sign_up/sign_up.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    bool isCheck = false;

    return Scaffold(
      backgroundColor: context.theme.cardColor,
      body: SingleChildScrollView(
        child: SafeArea(
            child: Column(
          children: [
            // Container(
            //   height: height / 30,
            // ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(left: 15, top: 10),
                  child: CircleAvatar(
                    radius: 20,
                    backgroundColor: context.theme.backgroundColor,
                    child: Icon(
                      Icons.arrow_back,
                      color: context.theme.textTheme.headline1?.color,
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: height / 25,
            ),
            Row(
              children: [
                'Welcome Back'.TitelText(context),
              ],
            ).marginOnly(
              left: 22,
            ),

            Row(
              children: [
                'Welcome Back! Please Enter Your Details.'.SubTitelText(),
              ],
            ).marginOnly(left: 22, top: 10),

            Row(
              children: [
                'Email'.TegText(context),
              ],
            ).marginOnly(left: 22, top: 30),
            Container(
              decoration: BoxDecoration(
                  color: context.theme.backgroundColor, borderRadius: BorderRadius.circular(10)),
              margin: EdgeInsets.only(left: 15),
              child: Container(
                margin: EdgeInsets.only(left: 15),
                child: TextField(
                  controller: emailController,
                  cursorColor: Color(0xff7E7E7E),
                  decoration: const InputDecoration(
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      hintText: 'Enter your email',
                      hintStyle: TextStyle(color: Color(0xff7E7E7E))),
                ),
              ),
            ).marginOnly(top: 10, right: 20),
            Row(
              children: [
                'Password'.TegText(context),
              ],
            ).marginOnly(left: 22, top: 30),
            Container(
              decoration: BoxDecoration(
                  color: context.theme.backgroundColor, borderRadius: BorderRadius.circular(10)),
              margin: EdgeInsets.only(left: 15),
              child: Container(
                margin: EdgeInsets.only(left: 15),
                child: TextField(
                  controller: passwordController,
                  cursorColor: Color(0xff7E7E7E),
                  decoration: const InputDecoration(
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      hintText: 'Enter your Password',
                      hintStyle: TextStyle(color: Color(0xff7E7E7E))),
                ),
              ),
            ).marginOnly(top: 10, right: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Checkbox(
                    value: isCheck,
                    checkColor: Color(0xff0C8A7B),
                    activeColor: Colors.white,
                    onChanged: (value) {
                      setState(() {
                        isCheck = value!;
                      });
                    }).marginOnly(left: 5),
                Container(
                  child: 'Remember For 30 Days'.TegSubText(),
                ).marginOnly(right: 30),
                Container(
                  child: 'Forgot password'.TegText(context),
                ).marginOnly(right: 20)
              ],
            ).marginOnly(top: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  height: 50,
                  width: 300,
                  decoration: BoxDecoration(
                      color: AppColor.intoColor,
                      borderRadius: BorderRadius.circular(15)),
                  child: InkWell(
                    onTap: () {
                      print('------------>Login Page');
                      Navigator.pushReplacement(context, MaterialPageRoute(
                        builder: (context) {
                          return BottomNavigationBarPage();
                        },
                      ));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        'Sign in'.getText(),
                      ],
                    ),
                  ),
                )
              ],
            ).marginOnly(top: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  height: 50,
                  width: 300,
                  decoration: BoxDecoration(
                      color: context.theme.backgroundColor,
                      borderRadius: BorderRadius.circular(15)),
                  child: InkWell(
                    onTap: () {
                      // print('------------>Login Page');
                      // Navigator.pushReplacement(context, MaterialPageRoute(
                      //   builder: (context) {
                      //     return LoginPage();
                      //   },
                      // ));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AppIcon.googleImage().marginOnly(right: 10),
                        'Sign in with google'.TegText(context),
                      ],
                    ),
                  ),
                )
              ],
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushReplacement(context, MaterialPageRoute(
                  builder: (context) {
                    return SignUp();
                  },
                ));
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  'Don’t have an account?'.TegSubText(),
                  'Sign Up for free'.TegText(context)
                ],
              ),
            ),
            Container(
              height: height / 25,
            ),
          ],
        )),
      ),
    );
  }

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
}
